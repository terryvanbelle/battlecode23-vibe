package c_blind1;
import battlecode.common.*;
/** Owned instrumented wrappers: production calls are compiled out for period zero. */
public final class BlindCalibration {
    public static void hookAndStats() throws GameActionException {
        if (C.BLIND_PERIOD > 0) { Launcher.blindShot(); Launcher.blindStats(); }
    }
    public static void ordinaryThenHook() throws GameActionException {
        Launcher.shoot();
        if (C.BLIND_PERIOD > 0) { Launcher.blindShot(); Launcher.blindStats(); }
    }
    public static void emptyReference() { }
    public static int shared(RobotController rc) throws GameActionException { return rc.readSharedArray(5); }
    public static boolean map(RobotController rc, MapLocation p) { return rc.onTheMap(p); }
    public static int cd(RobotController rc) { return rc.getActionCooldownTurns(); }
    public static boolean senses(RobotController rc, MapLocation p) { return rc.canSenseLocation(p); }
    public static boolean attackable(RobotController rc, MapLocation p) { return rc.canAttack(p); }
    public static MapInfo info(RobotController rc, MapLocation p) throws GameActionException { return rc.senseMapInfo(p); }
    public static MapLocation[] clouds(RobotController rc) throws GameActionException { return rc.senseNearbyCloudLocations(16); }
    public static void attack(RobotController rc, MapLocation p) throws GameActionException { rc.attack(p); }
}
